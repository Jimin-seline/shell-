#!/bin/bash

echo "enter number"
read number

for ((i =0; i<$number;i++)); do
	echo "hello world"
done
